<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DATABASE_NAME', 'Almost Rent Anything');

define('CURRENCY', '&#8377');



?>